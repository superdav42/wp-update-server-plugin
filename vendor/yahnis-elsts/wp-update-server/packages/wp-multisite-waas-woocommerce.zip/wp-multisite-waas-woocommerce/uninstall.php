<?php
/**
 * WP Multisite WaaS - WooCommerce Gateways uninstall script.
 *
 * @package WP_Ultimo_WooCommerce
 * @since 2.0.0
 */

if (! defined('WP_UNINSTALL_PLUGIN')) {
	exit;
}
