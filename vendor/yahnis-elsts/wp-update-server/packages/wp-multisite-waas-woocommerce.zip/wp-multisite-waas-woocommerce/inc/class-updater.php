<?php
/**
 * Updates add-ons based on the main plugin license.
 *
 * @package WP_Ultimo_WooCommerce
 * @subpackage Updater
 * @since 2.0.0
 */

namespace WP_Ultimo_WooCommerce;

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * Updates add-ons based on the main plugin license.
 *
 * @since 2.0.0
 */
class Updater {

	use \WP_Ultimo_WooCommerce\Traits\Singleton;

	/**
	 * Holds the URL for serving build files.
	 *
	 * @var string
	 * @since 2.0.0
	 */
	public $updates_url = 'https://wp-multisite-waas.test/';

	/**
	 * Add the main hooks.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function init() {

		// Enable our auto updates library
		add_action('init', array($this, 'enable_auto_updates'));
	}

	/**
	 * Adds the auto-update hooks, if a license is present.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function enable_auto_updates() {


		$refresh_token = wu_get_option('wu-refresh-token');

		if ($refresh_token) {
			$access_token = get_transient('wu-access-token');

			if ( ! $access_token) {
				$url     = 'https://wp-multisite-waas.test/oauth/token';
				$data    = array(
					'grant_type'    => 'refresh_token',
					'client_id'     => '4xYlZXujMatEwrZ6t2dz6O15vyKT7X28xb39ZUQW',
					'client_secret' => 'b1k4yI4TG00IUDNXXNrTg1ycu2kOvM1kJS3saKFh',
					'refresh_token' => $refresh_token,
				);
				$request = \wp_remote_post(
					$url,
					[
						'body'      => $data,
						'sslverify' => defined('WP_DEBUG') && WP_DEBUG ? false : true,
					]
				);
				$body    = wp_remote_retrieve_body($request);
				$code    = wp_remote_retrieve_response_code($request);
				$message = wp_remote_retrieve_response_message($request);

				if (is_wp_error($request)) {
					throw new \Exception(esc_html($request->get_error_message()), esc_html($request->get_error_code()));
				}
				if (200 === absint($code) && 'OK' === $message) {
					$response     = json_decode($body, true);
					$access_token = $response['access_token'];
					set_transient('wu-access-token', $response['access_token'], $response['expires_in']);
				}
			}

			if ($access_token) {
				$url     = 'https://wp-multisite-waas.test/oauth/me';
				$request = \wp_remote_get(
					$url,
					[
						'headers'   => [
							'Authorization' => 'Bearer ' . $access_token,
						],
						'sslverify' => defined('WP_DEBUG') && WP_DEBUG ? false : true,
					]
				);
				$body    = wp_remote_retrieve_body($request);
				$code    = wp_remote_retrieve_response_code($request);
				$message = wp_remote_retrieve_response_message($request);
				if (is_wp_error($request)) {
					throw new \Exception(esc_html($request->get_error_message()), esc_html($request->get_error_code()));
				}
				if (200 === absint($code) && 'OK' === $message) {
					$user = json_decode($body, true);
				}
			}
		}

		$license_key = \WP_Ultimo\License::get_instance()->get_license_key();

		if (! $license_key) {
			return;
		}

		$url = add_query_arg(
			array(
				'license_key'        => rawurlencode($license_key),
				'update_slug'        => 'wp-multisite-waas-woocommerce',
				'update_action'      => 'get_metadata',
			),
			$this->updates_url
		);

		// Instantiating it
		$update_checker = \Puc_v4_Factory::buildUpdateChecker(
			$url,                           // Metadata URL.
			WP_ULTIMO_WOOCOMMERCE_PLUGIN_FILE,        // Full path to the main plugin file.
			'wp-multisite-waas-woocommerce'                   // Plugin slug. Usually it's the same as the name of the directory.
		);
		$update_checker->setAuthentication('Bearer ' . $access_token);
	}
}
