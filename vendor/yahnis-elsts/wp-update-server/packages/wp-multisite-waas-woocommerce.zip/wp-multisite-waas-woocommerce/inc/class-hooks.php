<?php
/**
 * WP Multisite WaaS - WooCommerce Gateways activation and deactivation hooks
 *
 * @package WP_Ultimo_WooCommerce
 * @subpackage Hooks
 * @since 2.0.0
 */

namespace WP_Ultimo_WooCommerce;

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WP Multisite WaaS - WooCommerce Gateways activation and deactivation hooks
 *
 * @since 2.0.0
 */
class Hooks {

	/**
	 * Static-only class.
	 */
	private function __construct() {}

	/**
	 * Register the activation and deactivation hooks
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public static function init() {

		/**
		 * Runs on WP Multisite WaaS - WooCommerce Gateways activation
		 */
		register_activation_hook(WP_ULTIMO_WOOCOMMERCE_PLUGIN_FILE, array('WP_Ultimo_WooCommerce\Hooks', 'on_activation'));

		/**
		 * Runs on WP Multisite WaaS - WooCommerce Gateways deactivation
		 */
		register_deactivation_hook(WP_ULTIMO_WOOCOMMERCE_PLUGIN_FILE, array('WP_Ultimo_WooCommerce\Hooks', 'on_deactivation'));

		/**
		 * Runs the activation hook.
		 */
		add_action('plugins_loaded', array('WP_Ultimo_WooCommerce\Hooks', 'on_activation_do'), 1);
	}

	/**
	 *  Runs when WP Multisite WaaS - WooCommerce Gateways is activated
	 *
	 * @since 1.9.6 It now uses hook-based approach, it is up to each sub-class to attach their own routines.
	 * @since 1.2.0
	 */
	public static function on_activation() {
		/*
		 * Set the activation flag
		 */
		update_network_option(null, 'wp_ultimo_woocommerce_activation', 'yes');
	}

	/**
	 * Runs whenever the activation flag is set.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public static function on_activation_do() {

		if (get_network_option(null, 'wp_ultimo_woocommerce_activation') === 'yes' && isset($_GET['activate'])) {

			// Removes the flag
			delete_network_option(null, 'wp_ultimo_woocommerce_activation');

			/**
			 * Let other parts of the plugin attach their routines for activation.
			 *
			 * @since 1.9.6
			 */
			do_action('wp_ultimo_woocommerce_activation');
		}
	}

	/**
	 * Runs when WP Multisite WaaS - WooCommerce Gateways is deactivated
	 *
	 * @since 1.9.6 It now uses hook-based approach, it is up to each sub-class to attach their own routines.
	 * @since 1.2.0
	 */
	public static function on_deactivation() {

		/**
		 * Let other parts of the plugin attach their routines for deactivation.
		 *
		 * @since 1.9.6
		 */
		do_action('wp_ultimo_woocommerce_deactivation');
	}
}
