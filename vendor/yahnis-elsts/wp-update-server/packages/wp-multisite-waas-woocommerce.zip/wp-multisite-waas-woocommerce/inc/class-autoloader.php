<?php
/**
 * WP Multisite WaaS - WooCommerce Gateways custom Autoloader.
 *
 * @package WP_Ultimo_WooCommerce
 * @subpackage Autoloader
 * @since 2.0.0
 */

namespace WP_Ultimo_WooCommerce;

use WP_Ultimo_WooCommerce\Dependencies\Pablo_Pacheco\WP_Namespace_Autoloader\WP_Namespace_Autoloader;

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * Auto-loads class files inside the inc folder.
 *
 * @since 2.0.0
 */
class Autoloader {

	/**
	 * Makes sure we are only using one instance of the class
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Static-only class.
	 */
	private function __construct() {}

	/**
	 * Initializes our custom autoloader
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public static function init() {

		if (! static::$instance instanceof static) {
			static::$instance = new WP_Namespace_Autoloader(
				array(
					'directory'            => dirname(__DIR__),
					'namespace_prefix'     => 'WP_Ultimo_WooCommerce',
					'classes_dir'          => 'inc',
					'lowercase'            => array('file', 'folders'),
					'underscore_to_hyphen' => array('file', 'folders'),
					'debug'                => self::is_debug(),
				)
			);

			static::$instance->init();
		}
	}

	/**
	 * Checks for unit tests and WP_DEBUG.
	 *
	 * @since 2.0.0
	 * @return boolean
	 */
	public static function is_debug() {

		if (defined('WP_TESTS_MULTISITE') && WP_TESTS_MULTISITE) {
			return false;
		}

		return defined('WP_DEBUG') && WP_DEBUG;
	}
}
