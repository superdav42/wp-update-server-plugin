<?php
/**
 * WP Ultimo Tax VAT Support.
 *
 * This is heavily inspired on the worked developed by the Aelia team
 * in special on their WooCommerce VAT Support Plugin.
 *
 * @see https://aelia.co/shop/eu-vat-assistant-woocommerce/
 *
 * @package WP_Ultimo_VAT
 * @subpackage Tax
 * @since 2.0.0
 */

namespace WP_Ultimo_VAT\Tax;

use \WP_Ultimo_VAT\Tax\Vat_Validation;

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WP Ultimo helper methods for including and rendering files, assets, etc
 *
 * @since 2.0.0
 */
class EU_Vat {

	use \WP_Ultimo_VAT\Traits\Singleton;

	/**
	 * Cache key to save EU Vat Rates
	 */
	const EU_VAT_RATES_CACHE_KEY = 'wu_eu_vat_rates';

	/**
	 * Cache key to save VAT validation data about a VAT number.
	 */
	const EU_VAT_CHECK_CACHE_KEY = 'wu_eu_vat_check';

	/**
	 * Adds hooks to be added at the original instantiations.
	 *
	 * @since 1.9.0
	 */
	public function init() {

		add_action('init', array($this, 'add_settings'));

		if ($this->is_enabled()) {

			$this->load_admin_hooks();

			$this->load_checkout_hooks();

		} // end if;

	} // end init;

	/**
	 * Checks if this functionality is enabled.
	 *
	 * @since 2.0.0
	 * @return boolean
	 */
	public function is_enabled() {

		$is_enabled = wu_get_setting('eu_vat_enable', false);

		return apply_filters('wu_eu_vat_enable', $is_enabled);

	} // end is_enabled;

	/**
	 * Loads the checkout hooks.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	protected function load_checkout_hooks() {

		add_action('wu_checkout_scripts', array($this, 'register_checkout_scripts'));

		add_filter('wu_checkout_form_final_fields', array($this, 'add_vat_number_checkout_field'), 10, 2);

		add_action('wu_cart_setup', array($this, 'add_vat_data_to_order'));

		add_action('wu_cart_after_setup', array($this, 'check_if_customer_is_on_europe'));

		add_filter('wu_cart_is_tax_exempt', array($this, 'maybe_set_exempt_status'), 10, 2);

		add_filter('wu_cart_applicable_tax_rates', array($this, 'maybe_use_home_country_tax_rates'), 10, 4);

	} // end load_checkout_hooks;

	/**
	 * Loads the admin hooks.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	protected function load_admin_hooks() {

		add_action('wu_load_tax_rates_list_page', array($this, 'register_scripts'));

		add_action('wp_ajax_wu_get_eu_vat_tax_rates', array($this, 'serve_eu_vat_taxes_rates_via_ajax'));

		add_action('wu_tax_rates_screen_additional_actions', array($this, 'print_eu_vat_actions'));

		add_filter('wu_get_tax_rate_types', array($this, 'add_eu_vat_tax_rate_type'));

	} // end load_admin_hooks;

	/**
	 * Register the checkout scripts.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function register_checkout_scripts() {

		wp_register_script('wu-vat', wu_vat_get_asset('vat.js', 'js'), array('wu-checkout'), wu_vat_get_version(), true);

		wp_enqueue_script('wu-vat');

	} // end register_checkout_scripts;

	/**
	 * Adds the vat number field when necessary.
	 *
	 * @since 2.0.0
	 *
	 * @param array $fields The checkout fields.
	 * @return array
	 */
	public function add_vat_number_checkout_field($fields) {

		$valid_tag = sprintf('<span v-cloak v-if="vat_valid" class="wu-float-right wu-text-green-500 wu-text-2xs wu-uppercase wu-font-bold wu-mt-1">
			<span class="dashicons-wu-check wu-align-middle wu-mr-1"></span>%s</span>', __('Valid VAT Number', 'wp-ultimo-vat'));

		$vat_number_fields = array(
			'vat_clear'  => array(
				'type' => 'clear',
			),
			'vat_number' => array(
				'type'              => 'text',
				'id'                => 'vat_number',
				'title'             => wu_get_setting('eu_vat_field_label', '') . $valid_tag,
				'tooltip'           => wu_get_setting('eu_vat_field_tooltip', ''),
				'html_attr'         => array(
					'v-on:input.lazy' => 'vat_number = $event.target.value.toUpperCase().replace(/[^A-Z0-9-_]+/g, "")',
					'v-bind:value'    => 'vat_number',
				),
				'wrapper_html_attr' => array(
					'v-show' => 'vat_is_customer_on_eu',
				),
			),
		);

		/*
		 * Calculates the place to add the field.
		 *
		 * By default, adds it after the billing country.
		 */
		$place_to_position = array_search('billing_country', array_keys($fields), true);

		if ($place_to_position === false) {

			return $fields;

		} // end if;

		array_splice($fields, $place_to_position + 1, 0, $vat_number_fields);

		return $fields;

	} // end add_vat_number_checkout_field;

	/**
	 * Add the VAT variables to the cart object.
	 *
	 * @since 2.0.0
	 *
	 * @param \WP_Ultimo\Checkout\Cart $cart The cart object.
	 * @return void
	 */
	public function add_vat_data_to_order($cart) {

		$cart->set_param('vat_number', wu_request('vat_number', ''));

		$cart->set_param('vat_valid', false);

		$cart->set_param('vat_is_customer_on_eu', false);

	} // end add_vat_data_to_order;

	/**
	 * Checks if the current customer is on an EU country.
	 *
	 * @since 2.0.0
	 *
	 * @param \WP_Ultimo\Checkout\Cart $cart The cart object.
	 * @return void
	 */
	public function check_if_customer_is_on_europe($cart) {

		$is_customer_on_eu = $this->is_customer_on_eu_country($cart->get_country());

		$cart->set_param('vat_is_customer_on_eu', $is_customer_on_eu);

	} // end check_if_customer_is_on_europe;

	/**
	 * Check if we need to exempt the purchase from VAT validation.
	 *
	 * @since 2.0.0
	 *
	 * @param bool                     $exempt_status The current exempt status.
	 * @param \WP_Ultimo\Checkout\Cart $cart The cart object.
	 * @return bool
	 */
	public function maybe_set_exempt_status($exempt_status, $cart) {

		$vat_number = $cart->get_param('vat_number');

		$country = $cart->get_country();

		if ($vat_number) {

			$invalid_request = $this->is_request_invalid($country, $vat_number);

			if ($invalid_request) {

				if (!$cart->errors->has_errors()) {

					$cart->errors->add('vat-number', __('Invalid VAT Number.', 'wp-ultimo-vat'));

				} // end if;

				return false;

			} // end if;

			$parsed_number = $this->parse_vat_number($vat_number);

			$valid_vat_number = $this->validate_vat_number($country, $parsed_number);

			if ($valid_vat_number) {

				$cart->set_param('vat_valid', true);

				return true;

			} else {

				if (!$cart->errors->has_errors()) {

					$cart->errors->add('vat-number', __('Invalid VAT Number.', 'wp-ultimo-vat'));

				} // end if;

				return false;

			} // end if;

		} // end if;

		return $exempt_status;

	} // end maybe_set_exempt_status;

	/**
	 * Checks if we need to replace tax rates with the home country.
	 *
	 * @since 2.0.0
	 *
	 * @param array                    $tax_rates Existing tax rates.
	 * @param string                   $country The country on the cart session.
	 * @param string                   $tax_category The tax category.
	 * @param \WP_Ultimo\Checkout\Cart $cart The cart object.
	 * @return array
	 */
	public function maybe_use_home_country_tax_rates($tax_rates, $country, $tax_category, $cart) {

		if (wu_get_setting('eu_vat_use_home_country', false)) {

			$home_country_tax_rates = wu_get_applicable_tax_rates(wu_get_setting('company_country', ''), $tax_category);

			return $home_country_tax_rates;

		} // end if;

		return $tax_rates;

	} // end maybe_use_home_country_tax_rates;

	/*
	 * Admin Methods
	 */

	/**
	 * Adds the additional settings need for EU VAT support.
	 *
	 * @return void
	 */
	public function add_settings() {

		wu_register_settings_field('taxes', 'vat_header', array(
			'title'   => __('EU VAT Options', 'wp-ultimo-vat'),
			'desc'    => __('Use the options below to add support to EU VAT.', 'wp-ultimo-vat'),
			'type'    => 'header',
			'require' => array(
				'enable_taxes' => 1,
			),
		));

		wu_register_settings_field('taxes', 'eu_vat_enable', array(
			'title'   => __('Enable EU VAT Support', 'wp-ultimo-vat'),
			'desc'    => __('WP ultimo offers a set of tools to help your network achieve EU VAT compliance. Activate this options if you need to support EU VAT.', 'wp-ultimo-vat'),
			'tooltip' => '',
			'type'    => 'toggle',
			'default' => false,
			'require' => array(
				'enable_taxes' => 1,
			),
		));

		wu_register_settings_field('taxes', 'eu_vat_field_label', array(
			'title'       => __('EU VAT Field Label', 'wp-ultimo-vat'),
			'desc'        => __('Customize the label of the VAT number field.', 'wp-ultimo-vat'),
			'tooltip'     => '',
			'type'        => 'text',
			'default'     => __('VAT Number', 'wp-ultimo-vat'),
			'placeholder' => __('VAT Number', 'wp-ultimo-vat'),
			'require'     => array(
				'enable_taxes'  => 1,
				'eu_vat_enable' => 1,
			),
		));

		wu_register_settings_field('taxes', 'eu_vat_field_tooltip', array(
			'title'       => __('EU VAT Field Tooltip', 'wp-ultimo-vat'),
			'desc'        => __('You can enter a helper text to be displayed on a tooltip for the EU VAT Field. Leave blank if you do not want to display a tooltip.', 'wp-ultimo-vat'),
			'tooltip'     => '',
			'type'        => 'text',
			'default'     => __('Enter your EU VAT Number (if any). Country prefix is not required.', 'wp-ultimo-vat'),
			'placeholder' => __('Enter your EU VAT Number (if any). Country prefix is not required.', 'wp-ultimo-vat'),
			'require'     => array(
				'enable_taxes'  => 1,
				'eu_vat_enable' => 1,
			),
		));

		wu_register_settings_field('taxes', 'eu_vat_use_home_country', array(
			'title'   => __('Charge VAT of home country', 'wp-ultimo-vat'),
			'desc'    => __('If your annual revenue is EUR 10.000 or less, you might be eligible to charge your home country\'s VAT rate for all transactions, regardless of customer location. Check with a tax professional before toggling this option.', 'wp-ultimo-vat'),
			'tooltip' => '',
			'type'    => 'toggle',
			'default' => false,
			'require' => array(
				'enable_taxes'  => 1,
				'eu_vat_enable' => 1,
			),
		));

	} // end add_settings;

	/**
	 * Add additional methods for the fetching Tax Rates functions.
	 *
	 * @since 0.0.1
	 * @return void
	 */
	public function register_scripts() {

		wp_enqueue_script('wu-vat', wu_vat_get_asset('tax-rates-vat.js', 'js'), array('jquery', 'wu-tax-rates'), wu_vat_get_version());

	} // end register_scripts;

	/**
	 * Adds the EU VAT tax rate type to the types list.
	 *
	 * @since 2.0.0
	 * @param array $types Current tax rate types.
	 * @return array
	 */
	public function add_eu_vat_tax_rate_type($types) {

		$types['eu-vat'] = __('EU VAT', 'wp-ultimo-vat');

		return $types;

	} // end add_eu_vat_tax_rate_type;

	/**
	 * Retrieves the list of VAT rates and returns them.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function serve_eu_vat_taxes_rates_via_ajax() {

		$rate_type = wu_request('rate_type', 'standard_rate');

		$eu_vat_tax_rates = $this->get_eu_vat_rates();

		/**
		 * Loop the results and return the array with contents
		 */
		$results = array();

		foreach ($eu_vat_tax_rates['rates'] as $country_code => $item) {

			$rate = (float) isset($item[$rate_type]) && $item[$rate_type] ? $item[$rate_type] : $item['standard_rate'];

			$results[] = array(
				'title'    => sprintf(__('%1$s VAT', 'wp-ultimo-vat'), $item['country']),
				'country'  => $country_code,
				'tax_rate' => $rate,
				'state'    => '',
				'priority' => '1',
				'type'     => 'eu-vat',
				'compound' => false,
				'selected' => true,
				'ID'       => null,
			);

		} // end foreach;

		$vat_rates = apply_filters('wu_get_eu_vat_tax_rates', $results);

		wp_send_json_success($vat_rates);

	} // end serve_eu_vat_taxes_rates_via_ajax;

	/**
	 * Prints the Update EU VAT action buttons.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function print_eu_vat_actions() {

		// phpcs:disable
		
		?>

		<button v-on:click="pull_vat_data" class="button">
			<?php _e('Update EU VAT Rates'); ?>
		</button>

		<select v-model="rate_type">

			<option value="standard_rate">
				<?php echo _e('Use Standard Rates', 'wp-ultimo-vat'); ?>
			</option>

			<option value="reduced_rate">
				<?php echo _e('Use Reduced Rates', 'wp-ultimo-vat'); ?>
			</option>

			<option value="reduced_rate_alt">
				<?php echo _e('Use Reduced Rates (Alternative)', 'wp-ultimo-vat'); ?>
			</option>

			<option value="super_reduced_rates">
				<?php echo _e('Use Super Reduced Rates', 'wp-ultimo-vat'); ?>
			</option>

			<option value="parking_rate">
				<?php echo _e('Use Parking Rates', 'wp-ultimo-vat'); ?>
			</option>

		</select>

		<span style="line-height: 30px;" title='<?php _e('Please, keep in mind that if alternative rates are not found for some country, the standard rate will be used instead.', 'wp-ultimo-vat'); ?>' class='wu-tooltip-vue dashicons dashicons-editor-help'></span>

		<?php

		// phpcs:enable

	} // end print_eu_vat_actions;

	/*
	 * Helper Methods
	 */

	/**
	 * Checks if the VAT rates retrieved by the EU VAT Assistant are valid. Rates
	 * are valid when, for each country, they contain at least a standard rate
	 * (invalid rates often have a "null" object associated to them).
	 *
	 * @param array $vat_rates An array containing the VAT rates for all EU countries.
	 * @return bool
	 */
	protected function valid_eu_vat_rates($vat_rates) {

		foreach ($vat_rates as $country_code => $rates) {

			if (empty($rates['standard_rate']) || !is_numeric($rates['standard_rate'])) {

				return false;

			} // end if;

		} // end foreach;

		return true;

	} // end valid_eu_vat_rates;

	/**
	 * Retrieves the EU VAT rats from https://euvatrates.com website.
	 *
	 * @return array|null An array with the details of VAT rates, or null on failure.
	 * @link https://euvatrates.com
	 */
	public function get_eu_vat_rates() {

		$vat_rates = get_site_transient(self::EU_VAT_RATES_CACHE_KEY);

		if (!empty($vat_rates) && is_array($vat_rates)) {

			return $vat_rates;

		} // end if;

		$eu_vat_source_urls = array(
			// Forked Github repository at https://github.com/aelia-co/euvatrates.com
			// @since 1.7.16.171215
			'https://raw.githubusercontent.com/aelia-co/euvatrates.com/master/rates.json',
			// Original VAT rate service. It should work, although it might contain
			// obsolete VAT rates
			'http://euvatrates.com/rates.json',
		);

		// Go through the available URLs to get the rates
		foreach ($eu_vat_source_urls as $eu_vat_url) {

			$eu_vat_response = wp_remote_get($eu_vat_url, array(
				'timeout' => 5,
			));

			// Stop as soon as we get a valid response (i.e. NOT a WP Error)
			if (!is_wp_error($eu_vat_response)) {

				// We got a valid response. Now ensure that the VAT rates are in the
				// correct format
				$vat_rates = json_decode(wp_remote_retrieve_body($eu_vat_response), true);

				if (($vat_rates === null) || !is_array($vat_rates) || !isset($vat_rates['rates'])) {

					$vat_rates = null;

				} else {

					// If we reach this point, we got a valid response and the VAT rates
					// are most likely in the correct format. We can stop the loop here
					break;

				} // end if;
			} else {

				// TODO: LOG ERROR

			} // end if;

		} // end foreach;

		// If we reach this point and the VAT rates are still null, then the rates
		// could not be retrieved
		// @since 1.7.16.171215
		if ($vat_rates === null) {

			return null;

		} // end if;

		// Add rates for countries that use other countries' tax rates
		// Monaco uses French VAT
		$vat_rates['rates']['MC']            = $vat_rates['rates']['FR'];
		$vat_rates['rates']['MC']['country'] = 'Monaco';

		// Isle of Man uses UK's VAT
		$vat_rates['rates']['IM']            = $vat_rates['rates']['UK'];
		$vat_rates['rates']['IM']['country'] = 'Isle of Man';

		// Fix the country codes received from the feed. Some country codes are
		// actually the VAT country code. We need the ISO Code instead.
		$country_codes_to_fix = array(
			'EL' => 'GR',
			'UK' => 'GB',
		);

		foreach ($country_codes_to_fix as $code => $correct_code) {

			$vat_rates['rates'][$correct_code] = $vat_rates['rates'][$code];

			unset($vat_rates['rates'][$code]);

		} // end foreach;

		/*
		 * Fix the VAT rates for countries that don't have a reduced VAT rate. For
		 * those countries, the standard rate should be used as the "reduced" rate.
		 */
		foreach ($vat_rates['rates'] as $country_code => $rates) {

			if (!is_numeric($rates['reduced_rate'])) {

				$rates['reduced_rate'] = $rates['standard_rate'];

			} // end if;

			$vat_rates['rates'][$country_code] = $rates;

		} // end foreach;

		ksort($vat_rates['rates']);

		// Ensure that the VAT rates are valid before caching them
		if ($this->valid_eu_vat_rates($vat_rates['rates'])) {

			// Cache the VAT rates, to prevent unnecessary calls to the remote site
			set_site_transient(self::EU_VAT_RATES_CACHE_KEY, $vat_rates, 3 * HOUR_IN_SECONDS);

		} // end if;

		return $vat_rates;

	} // end get_eu_vat_rates;

	/**
	 * Returns sn associative array of country code => EU VAT prefix pairs.
	 *
	 * @since 2.0.0
	 * @return array
	 */
	protected function get_eu_vat_country_prefixes() {

		$eu_vat_country_prefixes = array();

		foreach ($this->get_eu_countries() as $country_code) {

			$eu_vat_country_prefixes[$country_code] = $country_code;

		} // end foreach;

		// Correct vat prefixes that don't match the country code and add some extra ones
		// Greece
		$eu_vat_country_prefixes['GR'] = 'EL';
		// Isle of Man
		$eu_vat_country_prefixes['IM'] = 'GB';
		// Monaco
		$eu_vat_country_prefixes['MC'] = 'FR';

		return apply_filters('wu_get_eu_vat_country_prefixes', $eu_vat_country_prefixes);

	} // end get_eu_vat_country_prefixes;

	/**
	 * Parses a VAT number, removing special characters and the country prefix, if
	 * any.
	 *
	 * @since 2.0.0
	 *
	 * @param string $vat_number The VAT number to parse.
	 * @return string
	 */
	public function parse_vat_number($vat_number) {

		// Remove special characters
		$vat_number = strtoupper(str_replace(array(' ', '-', '_', '.'), '', $vat_number));

		// Remove country code if set at the beginning
		$prefix = substr($vat_number, 0, 2);

		$eu_countries = $this->get_eu_vat_country_prefixes();

		if (in_array($prefix, array_values($eu_countries), true)) {

			$vat_number = substr($vat_number, 2);

		} // end if;

		if (empty($vat_number)) {

			return false;

		} // end if;

		return $vat_number;

	} // end parse_vat_number;

	/**
	 * Returns the VAT prefix used by a specific country.
	 *
	 * @param string $country An ISO country code.
	 * @return string|false
	 */
	public function get_vat_prefix($country) {

		$country_prefixes = $this->get_eu_vat_country_prefixes();

		return in_array($country, $country_prefixes, true) ? $country_prefixes[$country] : false;

	} // end get_vat_prefix;

	/**
	 * Validates the argument passed for validation, transforming a country code
	 * into a VAT prefix and checking the VAT number before it's used for a VIES
	 * request.
	 *
	 * @param string $country_code A country code. It will be used to determine the VAT number prefix.
	 * @param string $vat_number A VAT number.
	 * @return bool
	 */
	public function is_request_invalid($country_code, $vat_number) {

		$vat_number = $this->parse_vat_number($vat_number);

		if ($vat_number === false) {

			return sprintf(__('An empty or invalid VAT number was passed for validation. The VAT number should contain several digits, without the country prefix. Received VAT number: "%s".', 'wp-ultimo-vat'), $vat_number);

		} // end if;

		$vat_prefix = $this->get_vat_prefix($country_code);

		if (empty($vat_prefix)) {

			return sprintf(__('A VAT prefix could not be found for the specified country. Received country code: "%s".', 'wp-ultimo-vat'), $country_code);

		} // end if;

		return false;

	} // end is_request_invalid;

	/**
	 * Caches the results of a particular check
	 *
	 * @since 2.0.0
	 * @param string $country_code The country code.
	 * @param string $vat_number The VAT number for the company or individual.
	 * @param bool   $valid If it was valid or not.
	 * @param array  $info The information about the company or individual.
	 * @return bool
	 */
	public function set_cache_vat_result($country_code, $vat_number, $valid, $info) {

		return set_site_transient(self::EU_VAT_CHECK_CACHE_KEY . '_' . $country_code . $vat_number, array(
			'valid'        => $valid,
			'country_code' => $country_code,
			'vat_number'   => $vat_number,
			'info'         => $info,
		), HOUR_IN_SECONDS);

	}  // end set_cache_vat_result;

	/**
	 * Return the caches value of a check result.
	 *
	 * @param string $country_code The country code.
	 * @param string $vat_number The VAT number.
	 * @return array|bool
	 */
	public function get_cache_vat_result($country_code, $vat_number) {

		return get_site_transient(self::EU_VAT_CHECK_CACHE_KEY . '_' . $country_code . $vat_number);

	} // end get_cache_vat_result;

	/**
	 * Validates a given VAT Number.
	 *
	 * @param string $country_code The country code.
	 * @param string $vat_number The VAT number.
	 * @return bool
	 */
	public function validate_vat_number($country_code, $vat_number) {

		// Checks of PHP has SOAP enabled
		if (!class_exists('SoapClient')) {

			return false;

		} // end if;

		$cache = $this->get_cache_vat_result($country_code, $vat_number);

		// Check if we had it in cache
		if ($cache && $cache['valid']) {

			return $cache['valid'];

		} else {

			$vat_validation = new Vat_Validation(array('debug' => false));

			try {

				$valid = $vat_validation->check($country_code, $vat_number);

			} catch (\Exception $e) {

				$valid = false;

			} // end try;

			// Saves Cache
			$info = $valid ? array(
				'denomination' => $vat_validation->getDenomination(),
				'name'         => $vat_validation->getName(),
				'address'      => $vat_validation->getAddress()
			) : array();

			$this->set_cache_vat_result($country_code, $vat_number, $valid, $info);

			return $valid;

		} // end if;

	} // end validate_vat_number;

	/**
	 * Returns a list of all EU Countries
	 *
	 * @since 2.0.0
	 * @return array
	 */
	public function get_eu_countries() {

		$eu_country_codes = array(
			'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DE',
			'DK', 'EE', 'EL', 'ES', 'FI', 'FR', 'GB',
			'HU', 'IE', 'IT', 'LT', 'LU', 'LV', 'MT',
			'NL', 'PL', 'PT', 'RO', 'SE', 'SI', 'SK',
			'MC', 'IM',
		);

		return apply_filters('wu_eu_country_codes', $eu_country_codes);

	} // end get_eu_countries;

	/**
	 * Checks if the current customer is on a EU member country
	 *
	 * @since 2.0.0
	 * @param string $country Country code.
	 * @return boolean
	 */
	public function is_customer_on_eu_country($country) {

		$eu_country_codes = $this->get_eu_countries();

		return in_array($country, $eu_country_codes, true);

	} // end is_customer_on_eu_country;

} // end class EU_Vat;
