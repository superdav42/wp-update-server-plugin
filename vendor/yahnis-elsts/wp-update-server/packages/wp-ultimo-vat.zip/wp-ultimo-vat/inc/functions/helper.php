<?php
/**
 * General helper functions for WP Ultimo: European VAT.
 *
 * @author      Arindo Duque
 * @category    Admin
 * @package     WP_Ultimo_Multi_Currency/Helper
 * @version     2.0.0
 */

/**
 * Returns the WP Ultimo: European VAT version.
 *
 * @since 2.0.0
 * @return string
 */
function wu_vat_get_version() {

	return WP_Ultimo_VAT()->version;

} // end wu_vat_get_version;

/**
 * Returns the URL for assets inside the assets folder.
 *
 * @since 2.0.0
 *
 * @param string $asset Asset file name with the extension.
 * @param string $assets_dir Assets sub-directory. Defaults to 'img'.
 * @param string $base_dir   Base dir. Defaults to 'assets'.
 * @return string
 */
function wu_vat_get_asset($asset, $assets_dir = 'img', $base_dir = 'assets') {

	return WP_Ultimo_VAT()->helper->get_asset($asset, $assets_dir, $base_dir);

} // end wu_vat_get_asset;
