<?php
/**
 * WP Ultimo: European VAT uninstall script.
 *
 * @package WP_Ultimo_VAT
 * @since 1.0.0
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {

	exit;

} // end if;
