/**
 * Adds additional checkout parameters.
 */
wp.hooks.addFilter('wu_before_form_init', 'nextpress/wp-ultimo-vat', function(data) {

  data.vat_number = '';

  data.vat_valid = false;

  data.vat_is_customer_on_eu = false;

  return data;

});

/**
 * Adds the vat number field to the watchers list.
 */
wp.hooks.addAction('wu_checkout_loaded', 'nextpress/wp-ultimo-vat', function(checkout) {

  checkout.$watch('vat_number', function() {

    checkout.create_order();

  });

});

/**
 * Update values after validation and other changes.
 */
wp.hooks.addAction('wu_on_create_order', 'nextpress/wp-ultimo-vat', function(checkout, data) {

  checkout.vat_valid = data.order.extra.vat_valid;

  checkout.vat_is_customer_on_eu = data.order.extra.vat_is_customer_on_eu;

});
