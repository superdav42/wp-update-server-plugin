=== WP Ultimo: European VAT ===
Contributors: aanduque
Requires at least: 5.1
Tested up to: 5.8.1
Requires PHP: 7.1.4
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds additional features and tools to WP Ultimo's default tax handling to better support European VAT.

== Description ==

WP Ultimo: European VAT

Adds additional features and tools to WP Ultimo's default tax handling to better support European VAT.

== Installation ==

1. Upload 'wp-ultimo-vat' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Follow the step by step Wizard to set the plugin up

== Changelog ==

Version 1.0.0-beta.4 - 2021-09-24

* Added: filter wp_ultimo_skip_network_active_check for mu-plugins based setups;

Version 1.0.0 - 05/08/2021 - Initial Release